import * as React from 'react';
import { NativeBaseProvider, Box, Text } from 'native-base'



import ultimosScanner from './components/data'
import InfoMachine from './components/InfoMachine'



export default function App() {
  return (<NativeBaseProvider>
    <InfoMachine />
  </NativeBaseProvider>)
}